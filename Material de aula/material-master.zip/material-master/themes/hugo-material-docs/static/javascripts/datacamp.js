window.onload = function() {
  $(".powered-by-datacamp" ).not(':last').remove();
};