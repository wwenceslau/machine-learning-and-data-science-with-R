#!/bin/sh

Rscript build.R
